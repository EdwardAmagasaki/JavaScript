// First Impressions of <canvas> and CodePen
// Drawing 2D JS do0 Codes

var c = document.getElementById("myCanvas");

var ctx = c.getContext("2d");

ctx.beginPath();

ctx.arc(125,100,40,0,Math.PI);

ctx.stroke();